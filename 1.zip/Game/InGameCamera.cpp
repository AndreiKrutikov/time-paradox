//#include "InGameCamera.h"
//
//Camera & InGameCamera::update(const Physics::Geometry::Point & pivot, const Physics::Geometry::Point & target) {
//  cameraPosition = pivot + (target - halfScreen)*invZoom;
//  return *this;
//}

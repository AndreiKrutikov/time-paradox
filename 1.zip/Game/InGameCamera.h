//#pragma once
//#include "Camera.h"
//
//class InGameCamera : public Camera {
//public:
//  virtual Camera& update(const Physics::Geometry::Point& pivot, const Physics::Geometry::Point& target) override;
//  virtual ~InGameCamera() {};
//};
//
